<!DOCTYPE html>

<!-- hello.php -->

<html lang="en">

<head>

<meta charset="utf-8">

<title>My First PHP Web Page</title>

</head>

<body>

<?php

// First PHP script to say hello

echo '<h1>hello, world!</h1>';

?>

</body>

</html>