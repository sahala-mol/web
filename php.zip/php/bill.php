<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electricity Bill Calculator</title>
</head>
<body>

    <h2><center>Electricity Bill Calculator</center></h2>

    <?php
    // Function to sanitize and validate input
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

   
    $units = $tariff = "";
    
    
    $totalAmount = $fixedCharge = $energyCharge = $tax = $netAmount = 0;

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
       
        if (empty($_POST["units"])) {
            $unitsError = "Units consumed is required";
        } else {
            $units = test_input($_POST["units"]);
            if (!is_numeric($units) || $units < 0) {
                $unitsError = "Invalid input for units";
            }
        }

        
        if (empty($_POST["tariff"])) {
            $tariffError = "Tariff rate is required";
        } else {
            $tariff = test_input($_POST["tariff"]);
            if (!is_numeric($tariff) || $tariff < 0) {
                $tariffError = "Invalid input for tariff rate";
            }
        }

       
        if (empty($unitsError) && empty($tariffError)) {
           
            $fixedCharge = 50;
            $energyCharge = $units * $tariff;
            $tax = 0.18 * $energyCharge;

           
            $totalAmount = $fixedCharge + $energyCharge + $tax;

            $netAmount = $totalAmount - $tax;
        }
    }
    ?>
<center>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="units">Units Consumed:</label>
        <input type="text" id="units" name="units" value="<?php echo $units; ?>" required>
        <span class="error"><?php echo isset($unitsError) ? $unitsError : ''; ?></span>
        <br><br>

        <label for="tariff">Tariff Rate (per unit):</label>
        <input type="text" id="tariff" name="tariff" value="<?php echo $tariff; ?>" required>
        <span class="error"><?php echo isset($tariffError) ? $tariffError : ''; ?></span>
        <br><br>

        <input type="submit" value="Calculate Bill">
    </form>

    <?php if ($totalAmount > 0): ?>
        <h3>Electricity Bill Details</h3>
        <p><strong>Fixed Charge:</strong> Rs. <?php echo $fixedCharge; ?></p>
        <p><strong>Energy Charge:</strong> Rs. <?php echo $energyCharge; ?></p>
        <p><strong>Tax (18%):</strong> Rs. <?php echo $tax; ?></p>
        <p><strong>Total Amount:</strong> Rs. <?php echo $totalAmount; ?></p>
        <p><strong>Net Amount (after tax):</strong> Rs. <?php echo $netAmount; ?></p>
    <?php endif; ?>
</center>
</body>
</html>
