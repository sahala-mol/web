<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore</title>
</head>
<body>
    <center>
    <h1>Add Book</h1>
    <form action="" method="post">
        <label for="title">Title:</label>
        <input type="text" name="title" required><br><br>

        <label for="authors">Authors:</label>
        <input type="text" name="authors" required><br><br>

        <label for="edition">Edition:</label>
        <input type="text" name="edition" required><br><br>

        <label for="publisher">Publisher:</label>
        <input type="text" name="publisher" required><br><br>

        <input type="submit" name="addBook" value="Add Book">
    </form>

    <h1>Search Books</h1>
    <form action="" method="get">
        <label for="author">Author:</label>
        <input type="text" name="author" required><br><br>

        <input type="submit" name="searchBooks" value="Search">
    </form>


    <?php
    $conn = new mysqli("localhost", "root", "", "bookstore");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (isset($_POST['addBook'])) {
        $title = $_POST['title'];
        $authors = $_POST['authors'];
        $edition = $_POST['edition'];
        $publisher = $_POST['publisher'];

        $sql = "INSERT INTO books (title, authors, edition, publisher) VALUES ('$title', '$authors', '$edition', '$publisher')";

        if ($conn->query($sql) === TRUE) {
            echo "Book added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_GET['searchBooks'])) {
        $author = $_GET['author'];

        $sql = "SELECT * FROM books WHERE authors LIKE '%$author%'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<h2>Search Results:</h2>";
            while ($row = $result->fetch_assoc()) {
                echo "Title: " . $row['title'] . "<br>";
                echo "Authors: " . $row['authors'] . "<br>";
                echo "Edition: " . $row['edition'] . "<br>";
                echo "Publisher: " . $row['publisher'] . "<hr>";
            }
        } else {
            echo "No results found";
        }
    }

    $conn->close();
    ?>
    </center>
</body>
</html>
