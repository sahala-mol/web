<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <style>
        .error {
            color: red;
        }
    </style>
</head>
<body>

    <h2>REGISTRATION FORM</h2>

    <?php
    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    
    $name = $email = $phone = $address = $courses = "";

   
    $nameError = $emailError = $phoneError = $addressError = $coursesError = "";

   
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        if (empty($_POST["name"])) {
            $nameError = "Name is required";
        } else {
            $name = test_input($_POST["name"]);
        }
 if (empty($_POST["email"])) {
            $emailError = "Email is required";
        } else {
            $email = test_input($_POST["email"]);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailError = "Invalid email format";
            }
        }
        if (empty($_POST["phone"])) {
            $phoneError = "Phone is required";
        } else {
            $phone = test_input($_POST["phone"]);
            if (!preg_match("/^[0-9]{10}$/", $phone)) {
                $phoneError = "Invalid phone number";
            }
        }
        if (empty($_POST["address"])) {
            $addressError = "Address is required";
        } else {
            $address = test_input($_POST["address"]);
        }
        if (empty($_POST["courses"])) {
            $coursesError = "Select a course";
        } else {
            $courses = test_input($_POST["courses"]);
        }
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name:</label>
        <input type="text" size="65" id="name" name="name" required>
        <span class="error"><?php echo $nameError; ?></span>
        <br><br>

        <label for="email">Email:</label>
        <input type="email" size="65" id="email" name="email" required>
        <span class="error"><?php echo $emailError; ?></span>
        <br><br>

        <label for="phone">Phone:</label>
        <input type="tel" size="65" id="phone" name="phone" pattern="[0-9]{10}" required>
        <span class="error"><?php echo $phoneError; ?></span>
        <br><br>

        <label for="address">Address:</label>
        <textarea id="address" rows="4" cols="45" name="address" required></textarea>
        <span class="error"><?php echo $addressError; ?></span>
        <br><br>

        <label for="courses">Courses:</label>
        <select id="courses" name="courses" required>
            <option value="">Select a course</option>
            <option value="MCA">MCA</option>
            <option value="MTECH">MTECH</option>
            <option value="Msc">Msc</option>
            <option value="BTECH">BTECH</option>
            <!-- Add more options as needed -->
        </select>
        <span class="error"><?php echo $coursesError; ?></span>
        <br><br>

        <input type="submit" value="Submit">
    </form>

</body>
</html>
