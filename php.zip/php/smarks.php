<DOCTYPE! html>
<html>
<head>
<style>
#regform{  
  border: 5px outset black;
  background-color: grey;
  text-align: center;
  width: 600;
  height: 700;
  margin:auto;

}
table,tr,td,th{
  border: 1px solid black;
}
</style>
</head>
<body>
<center>
<div id="regform">
<h2> STUDENT MARKS DETAILS</h2>
<form name="marksForm" method="post">
<label for="adno">Admission no :</label> 
<input type="text" id="adno" name="adno" ><br><br> 
<label for="name">Full Name:</label> 
<input type="text" id="name" name="name" > <br><br>
<label for="class">class:</label> 
<input type="text" id="class" name="class" > <br><br>


<h4>Marks of the student </h4>
<label for="mark1">Mark1 :</label> 
<input type="text" id="mark1" name="mark1" ><br><br>
<label for="mark2">mark2:</label> 
<input type="text" id="mark2" name="mark2" ><br><br>
<label for="mark3">mark3:</label> 
<input type="text" id="mark3" name="mark3" ><br><br>
<label for="mark4">mark4:</label> 
<input type="text" id="mark4" name="mark4" ><br><br>

<input type="submit" name="submit" value="Submit"><br><br>

</form>
<script>
        function validateForm() {
            document.getElementById("fnameError").innerHTML = "";
 var name = document.getElementById("name").value;
 if (name === "") {
                document.getElementById("nameError").innerHTML = "Name is required";
                return;
            }
</script>
<?php
$conn= mysqli_connect("localhost","root","","exam");
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";

if (isset($_POST['submit']))
{
  $adno = $_POST['adno'];
  $name = $_POST['name'];
  $class = $_POST['class'];
  $mark1 = $_POST['mark1'];
  $mark2 = $_POST['mark2'];
  $mark3 = $_POST['mark3'];
  $mark4 = $_POST['mark4'];

  $sql="insert into marks values('$adno','$name','$class', $mark1, $mark2, $mark3, $mark4)";
  if (mysqli_query($conn, $sql)) {
     echo "<br>Inserted successfully";
  } else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}

 mysqli_close($conn);
?>
</div>
</center>
</body>
</html>