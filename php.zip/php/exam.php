<html>
<head>
<style>
#regform{
border=5px outset red;
background-color:cyan;
text-align:center;
width=600;
height=700;
margin:auto;
}
table tr,td,th
{
border:1px
solid black;
}
</style>
</head>
<body>
<div id="regform">
<h2>STUDENT MARK DETAILS</h2>
<form name="studentmarks"method="post">
<label for="Admission No">Admission no:</label>
<input type="text" id="adno" name="adno"><br><br>
<label for="Name">Fullname:</label>
<input type="text" id="name" name="fname"><br><br>
<label for="class">class:</label>
<input type="text" id="class" name="class"><br><br>
<h4>MARKS OF THE STUDENT</h4>
<label for="mark1">Mark1:</label>
<input type="text" id="mark1" name="mark1"><br><br>
<label for="mark2">Mark2:</label>
<input type="text" id="mark2" name="mark2"><br><br>
<label for="mark3">Mark3:</label>
<input type="text" id="mark3" name="mark3"><br><br>
<label for="mark4">Mark4:</label>
<input type="text" id="mark4" name="mark4"><br><br>
<input type="submit" name="submit" value="submit"><br><br>
</form>
<script>
function validateForm() {
document.getElementById("nameError").innerHTML="";
var name=document.getElementById("fname").value;
if(fname ==="")
{
document.getElementById("nameError").innerHTML="name is required";
return;}
</script>
<?php
$conn=mysqli_connect("localhost","root","","exam");
if(!$conn){
die("connection failed."mysqli_connect_error());
}
echo"connected succesfully"<br>;
if(isset($_post['submit'])){
$_adno=$_post['adno'};
$_fname=$_post['name'];
$_class=$_post['class'];
$_mark1=$_post['mark1'];
$_mark2=$_post['mark2'];
$_mark3=$_post['mark3'];
$_mark4=$_post['mark4'];
$sql="insert into marks values('$adno','$fname','$class',$mark1,$mark2,$mark3,$mark4)";
if(mysqli_query($conn,$sql))
{
echo "<br>inserted successfully";
}
else
{
echo "error."$sql"<br>"
mysqli_error($conn);
}
}
mysqli_close($conn);
?>
</div>
</body>
</html>