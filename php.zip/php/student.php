<?php
    $conn=mysqli_connect("localhost","root","","college");
?>
<html>
    <body>
        <h1>Student Registration Form</h1>
        <center>
        <form action="">
            stud_id <input type="text" name="id"><br><br>
            Name <input type="text" name="name"><br><br>
            Age <input type="text" name="age"><br><br>
            sex <input type="text" name="sex"><br><br>
            <input type="submit" value="submit" name="submit"><br><br>
        </form>
</center>
    </body>
</html>
<?php
    if(isset($_REQUEST["submit"])){
        $id=$_REQUEST["id"];
        $name=$_REQUEST["name"];
        $age=$_REQUEST["age"];
        $sex=$_REQUEST["sex"];
        $sql="insert into student values('$id', '$name', '$age',  '$sex')";
        $run=mysqli_query($conn,$sql);
        if($run){
            echo "Successfully inserted";
        }
        else{
            echo "Failed";
        }
    }
?>