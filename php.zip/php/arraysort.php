<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Names</title>
</head>

<body>
    <?php
    $students = array("sahala"=>"55", "beema"=>"23", "suhana"=>"59", "karun"=>"41", "reja"=>"53");

    echo "<strong>Original Array:</strong><br>";
    print_r($students);
    echo "<br><br>";

    asort($students);


    echo "<strong>Sorted Array (Ascending Order):</strong><br>";
    print_r($students);
    echo "<br><br>";

  
    arsort($students);

  
    echo "<strong>Sorted Array (Descending Order):</strong><br>";
    print_r($students);
    ?>
</body>

</html>
